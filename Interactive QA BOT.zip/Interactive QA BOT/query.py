from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

def retrieve_relevant_sections(query, paragraphs, embeddings):
    query_embedding = model.encode([query])
    similarities = cosine_similarity(query_embedding, embeddings)
    best_match_idx = np.argmax(similarities)
    return paragraphs[best_match_idx], similarities[0][best_match_idx]
