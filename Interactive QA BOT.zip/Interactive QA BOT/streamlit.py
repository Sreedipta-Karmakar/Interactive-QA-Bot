import streamlit as st

# Simple Streamlit interface
st.title("Document-Based Question Answering Bot")

# File upload
uploaded_file = st.file_uploader("Upload a PDF file", type="pdf")

if uploaded_file is not None:
    # Extract text from PDF
    doc_text = extract_text_from_pdf(uploaded_file)
    st.write("Document uploaded and processed.")

    # Display extracted text (Optional)
    if st.checkbox("Show extracted text"):
        st.write(doc_text)

    # Prepare document embeddings
    paragraphs, embeddings = create_embeddings(doc_text)

    # Query input
    user_query = st.text_input("Enter your question:")
    
    if user_query:
        # Retrieve answer
        answer, similarity = retrieve_relevant_sections(user_query, paragraphs, embeddings)
        st.write(f"Answer: {answer}")
        st.write(f"Similarity Score: {similarity:.2f}")
