import gradio as gr

def qa_interface(pdf, query):
    # Extract text and process the query
    doc_text = extract_text_from_pdf(pdf)
    paragraphs, embeddings = create_embeddings(doc_text)
    answer, _ = retrieve_relevant_sections(query, paragraphs, embeddings)
    return answer

# Create Gradio app
gr.Interface(fn=qa_interface, 
             inputs=[gr.inputs.File(label="Upload PDF"), 
                     gr.inputs.Textbox(lines=2, placeholder="Enter your question")], 
             outputs="text").launch()
